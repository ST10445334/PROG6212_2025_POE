﻿using System.Windows;
using System.Windows.Controls;

namespace CMCS
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OnLoginClick(object sender, RoutedEventArgs e)
        {
            // Simulate successful login
            LoginGrid.Visibility = Visibility.Collapsed;
            MainGrid.Visibility = Visibility.Visible;
        }

        private void OnNavigateToSubmit(object sender, RoutedEventArgs e)
        {
            // Simulate navigation to Submit tab
        }

        private void OnNavigateToApproval(object sender, RoutedEventArgs e)
        {
            // Simulate navigation to Approval tab
        }

        private void OnUploadClick(object sender, RoutedEventArgs e)
        {
            // Simulate file upload
            UploadedFileTextBlock.Text = "SampleDocument.pdf uploaded";
        }

        private void OnSubmitClick(object sender, RoutedEventArgs e)
        {
            // Simulate claim submission
            MessageBox.Show("Claim submitted successfully!");
        }

        private void OnViewDetailsClick(object sender, RoutedEventArgs e)
        {
            // Simulate showing claim details
            DetailsPanel.Visibility = Visibility.Visible;
        }

        private void OnApproveClick(object sender, RoutedEventArgs e)
        {
            // Simulate approval
            MessageBox.Show("Claim approved!");
        }

        private void OnRejectClick(object sender, RoutedEventArgs e)
        {
            // Simulate rejection
            MessageBox.Show("Claim rejected!");
        }
    }
}